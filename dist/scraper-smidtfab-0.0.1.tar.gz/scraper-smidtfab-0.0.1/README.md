# scraper

A package to scrape articles from various sources including newspapers and social media

As of now the following sources are included:
Newspapers:
- elpais
- new york times

Social media:
- reddit

